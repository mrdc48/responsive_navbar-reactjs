import React from 'react';


export const Menuitems = [
  {
    name : 'home',
    url : '#',
    cName : 'nav-links'
  },
  {
    name : 'project ',
    url : '#',
    cName : 'nav-links'
  },
  {
    name : ' service',
    url : '#',
    cName : 'nav-links'
    
  },
  {
    name : ' about us ',
    url : '#',
    cName : 'nav-links'
  }
  ]